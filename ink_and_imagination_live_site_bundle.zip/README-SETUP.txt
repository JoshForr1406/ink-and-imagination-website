INK & IMAGINATION WEBSITE — LIVE SETUP NOTES

Included:
- index.html: website
- admin/: Decap CMS admin interface and configuration
- content/books.json and content/updates.json: public content data
- content/books/ and content/updates/: CMS content folders
- media/: uploaded images

IMPORTANT:
This package is not live until you create and connect accounts and deploy it.
The CMS uses Decap Turbo's turbo-github backend. You must create a Decap Turbo site,
connect the GitHub repository, set the site ID in admin/config.yml, and configure the
approved admin URL. Check current Decap Turbo plan limits before inviting the second
editor; free plan may include only one seat, so a genuinely free two-editor setup may
need a different authentication arrangement.

Cloudflare Pages can host static files free on a pages.dev address. Connect the GitHub
repository to Cloudflare Pages and set the output directory to the repository root.
When the repo is updated, Cloudflare Pages redeploys automatically.

Do not share account passwords. Invite the second editor using the platform's access
controls. Test login and publishing before announcing the site.
